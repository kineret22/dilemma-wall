# קיר הדילמות הניהוליות

אפליקציית web לסשנים קבוצתיים — משתתפים שולחים תשובות אנונימיות, והמנחה רואה הכל בזמן אמת.

---

## קבצים

```
dilemma-wall/
├── public/
│   ├── index.html       ← מסך המשתתפים
│   └── moderator.html   ← לוח המנחה (זמן אמת)
├── netlify/
│   └── functions/
│       ├── answers.mjs  ← API: קריאה / שליחה / מחיקת תשובות
│       └── question.mjs ← API: קריאה / עדכון השאלה
├── netlify.toml
└── package.json
```

---

## העלאה ל-Netlify (5 דקות)

### שיטה א׳ — גרור ושחרר (הכי מהיר)

1. גש לאתר [app.netlify.com](https://app.netlify.com)
2. לחץ **"Add new site" → "Deploy manually"**
3. גרור את **תיקיית `dilemma-wall`** לאזור ה-drag-and-drop
4. המתן לסיום הבנייה

### שיטה ב׳ — GitHub

1. העלה את התיקייה ל-GitHub repository
2. ב-Netlify: **"Add new site" → "Import an existing project"**
3. חבר את ה-repo
4. הגדרות Build:
   - **Publish directory:** `public`
   - **Functions directory:** `netlify/functions`
5. לחץ **Deploy**

---

## הפעלת Netlify Blobs (חובה לאחר Deploy)

ב-Netlify, תחת **Site settings → Data → Blobs**, ודא שה-Blob store מופעל (בד״כ מופעל אוטומטית).

אין צורך בהגדרות נוספות — הפונקציות מגדירות את עצמן אוטומטית.

---

## שימוש בסשן

| מסך | כתובת |
|-----|--------|
| משתתפים | `https://your-site.netlify.app/` |
| מנחה | `https://your-site.netlify.app/moderator.html` |

### למנחה:
- **לוח המנחה** מתרענן כל 3 שניות אוטומטית
- ניתן **לשנות את השאלה** (מוחק תשובות קיימות)
- ניתן **לנקות את כל התשובות** בלחיצה אחת

---

## אבטחה

> 💡 לוח המנחה אינו מוגן בסיסמה כברירת מחדל.
> מומלץ לשנות את שם הקובץ `moderator.html` למשהו פחות צפוי,
> לדוגמה `dashboard-k7x2.html`, כדי למנוע גישה לא מורשית.
